# csml1000group2-assignment2
CSML1000 Group2 Assignment2

1. R Markdown file -> assignment2.Rmd
2. Generated hmlt report -> assignment2.html
3. Data -> ./data/wine-with-type-locaiton.csv
4. Shiny App -> https://yumingcui.shinyapps.io/WineAnalysis/
5. Shiny App source code -> ./WinAnalysis/app.R
6. Shiny App Data -> ./WinAnalysis/shiny.RData

